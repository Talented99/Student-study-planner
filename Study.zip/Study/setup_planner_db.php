<?php
require_once 'config.php';

try {
    // Create study_goals table if it doesn't exist
    $sql = "CREATE TABLE IF NOT EXISTS study_goals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        target_date DATE,
        status ENUM('Active', 'Completed', 'Abandoned') DEFAULT 'Active',
        priority ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
        category VARCHAR(100),
        tags TEXT,
        parent_task_id INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP NULL,
        FOREIGN KEY (parent_task_id) REFERENCES study_goals(id) ON DELETE SET NULL
    )";
    
    $pdo->exec($sql);
    echo "Study goals table created successfully!<br>";
    
    // Create study_sessions table for timer and Pomodoro tracking
    $sql = "CREATE TABLE IF NOT EXISTS study_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        task_id INT NULL,
        session_type ENUM('Focus', 'Break', 'Long Break') DEFAULT 'Focus',
        duration_minutes INT NOT NULL,
        start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        end_time TIMESTAMP NULL,
        status ENUM('Active', 'Completed', 'Paused') DEFAULT 'Active',
        notes TEXT,
        FOREIGN KEY (task_id) REFERENCES study_goals(id) ON DELETE SET NULL
    )";
    
    $pdo->exec($sql);
    echo "Study sessions table created successfully!<br>";
    
    // Create study_resources table for file and link management
    $sql = "CREATE TABLE IF NOT EXISTS study_resources (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        type ENUM('File', 'Link', 'Note') DEFAULT 'File',
        file_path VARCHAR(500) NULL,
        url VARCHAR(500) NULL,
        subject VARCHAR(100),
        tags TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Study resources table created successfully!<br>";
    
    // Create study_groups table for collaboration
    $sql = "CREATE TABLE IF NOT EXISTS study_groups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        created_by INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Study groups table created successfully!<br>";
    
    // Create group_members table
    $sql = "CREATE TABLE IF NOT EXISTS group_members (
        id INT AUTO_INCREMENT PRIMARY KEY,
        group_id INT NOT NULL,
        student_id INT NOT NULL DEFAULT 1,
        role ENUM('Admin', 'Member') DEFAULT 'Member',
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE
    )";
    
    $pdo->exec($sql);
    echo "Group members table created successfully!<br>";
    
    // Create shared_tasks table for group collaboration
    $sql = "CREATE TABLE IF NOT EXISTS shared_tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        group_id INT NOT NULL,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        assigned_to INT NULL,
        status ENUM('Pending', 'In Progress', 'Completed') DEFAULT 'Pending',
        due_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE
    )";
    
    $pdo->exec($sql);
    echo "Shared tasks table created successfully!<br>";
    
    // Create notifications table
    $sql = "CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        title VARCHAR(200) NOT NULL,
        message TEXT,
        type ENUM('Task', 'Reminder', 'Achievement', 'Group') DEFAULT 'Task',
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Notifications table created successfully!<br>";
    
    // Create achievements table for gamification
    $sql = "CREATE TABLE IF NOT EXISTS achievements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        icon VARCHAR(100),
        points INT DEFAULT 0,
        criteria_type ENUM('Tasks', 'Sessions', 'Streak', 'Time') DEFAULT 'Tasks',
        criteria_value INT DEFAULT 1
    )";
    
    $pdo->exec($sql);
    echo "Achievements table created successfully!<br>";
    
    // Create student_achievements table
    $sql = "CREATE TABLE IF NOT EXISTS student_achievements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        achievement_id INT NOT NULL,
        earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
    )";
    
    $pdo->exec($sql);
    echo "Student achievements table created successfully!<br>";
    
    // Create study_stats table for analytics
    $sql = "CREATE TABLE IF NOT EXISTS study_stats (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL DEFAULT 1,
        date DATE NOT NULL,
        total_study_time INT DEFAULT 0,
        tasks_completed INT DEFAULT 0,
        sessions_completed INT DEFAULT 0,
        streak_days INT DEFAULT 0,
        points_earned INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_student_date (student_id, date)
    )";
    
    $pdo->exec($sql);
    echo "Study stats table created successfully!<br>";
    
    // Create study_templates table
    $sql = "CREATE TABLE IF NOT EXISTS study_templates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        template_data TEXT,
        category VARCHAR(100),
        is_public BOOLEAN DEFAULT FALSE,
        created_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Study templates table created successfully!<br>";
    
    // Create a sample student if not exists
    $sql = "CREATE TABLE IF NOT EXISTS student (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        index_number VARCHAR(20) UNIQUE NOT NULL,
        gender ENUM('Male', 'Female', 'Other') NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100),
        phone VARCHAR(20),
        profile_picture VARCHAR(500),
        bio TEXT,
        total_points INT DEFAULT 0,
        current_streak INT DEFAULT 0,
        longest_streak INT DEFAULT 0,
        notification_preferences TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Student table created successfully!<br>";
    
    // Insert a sample student if not exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM student WHERE id = 1");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $hashed_password = password_hash('demo123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO student (id, name, index_number, gender, password, email) VALUES (1, 'Demo Student', 'DEMO001', 'Other', ?, 'demo@example.com')");
        $stmt->execute([$hashed_password]);
        echo "Sample student created successfully!<br>";
    }
    
    // Insert default achievements
    $achievements = [
        ['First Task', 'Complete your first study task', 'fas fa-star', 10, 'Tasks', 1],
        ['Task Master', 'Complete 10 tasks', 'fas fa-trophy', 50, 'Tasks', 10],
        ['Study Warrior', 'Complete 50 tasks', 'fas fa-crown', 200, 'Tasks', 50],
        ['Focus Master', 'Complete 10 study sessions', 'fas fa-brain', 30, 'Sessions', 10],
        ['Time Keeper', 'Study for 10 hours total', 'fas fa-clock', 100, 'Time', 600],
        ['Streak Starter', 'Maintain a 3-day study streak', 'fas fa-fire', 25, 'Streak', 3],
        ['Consistency King', 'Maintain a 7-day study streak', 'fas fa-fire', 100, 'Streak', 7],
        ['Marathon Runner', 'Maintain a 30-day study streak', 'fas fa-fire', 500, 'Streak', 30]
    ];
    
    foreach ($achievements as $achievement) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO achievements (name, description, icon, points, criteria_type, criteria_value) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute($achievement);
    }
    echo "Default achievements created successfully!<br>";
    
    // Insert default study templates
    $templates = [
        ['Pomodoro Study Session', '25-minute focused study with 5-minute breaks', '{"sessions": [{"type": "Focus", "duration": 25}, {"type": "Break", "duration": 5}, {"type": "Focus", "duration": 25}, {"type": "Break", "duration": 5}, {"type": "Focus", "duration": 25}, {"type": "Long Break", "duration": 15}]}', 'Study Technique', true],
        ['Exam Preparation', 'Comprehensive exam study plan', '{"tasks": [{"title": "Review lecture notes", "priority": "High"}, {"title": "Practice problems", "priority": "High"}, {"title": "Create flashcards", "priority": "Medium"}, {"title": "Take practice test", "priority": "High"}, {"title": "Review weak areas", "priority": "Medium"}]}', 'Exam Prep', true],
        ['Daily Study Routine', 'Basic daily study schedule', '{"tasks": [{"title": "Morning review", "priority": "Medium"}, {"title": "Afternoon practice", "priority": "High"}, {"title": "Evening summary", "priority": "Low"}]}', 'Daily Routine', true]
    ];
    
    foreach ($templates as $template) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO study_templates (name, description, template_data, category, is_public) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute($template);
    }
    echo "Default study templates created successfully!<br>";
    
    echo "<br>Database setup completed! All enhanced features are now available.<br>";
    echo "<a href='student_study_planner.php'>Go to Enhanced Student Study Planner</a>";
    
} catch (PDOException $e) {
    echo "Error setting up database: " . $e->getMessage();
}
?>