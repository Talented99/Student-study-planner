<?php
require_once 'config.php';

try {
    // Add new profile fields to student table
    $alter_queries = [
        "ALTER TABLE student ADD COLUMN IF NOT EXISTS bio TEXT",
        "ALTER TABLE student ADD COLUMN IF NOT EXISTS phone VARCHAR(20)",
        "ALTER TABLE student ADD COLUMN IF NOT EXISTS profile_picture VARCHAR(255)"
    ];
    
    foreach ($alter_queries as $query) {
        $pdo->exec($query);
        echo "Executed: " . $query . "<br>";
    }
    
    echo "<br>Database updated successfully! New profile fields added:<br>";
    echo "- bio (TEXT): For student biography<br>";
    echo "- phone (VARCHAR(20)): For phone number<br>";
    echo "- profile_picture (VARCHAR(255)): For profile picture path<br>";
    
} catch (PDOException $e) {
    echo "Error updating database: " . $e->getMessage();
}
?>
