<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit();
}

// Get comprehensive statistics
$stats = [
    'total' => 0,
    'active' => 0,
    'completed' => 0,
    'abandoned' => 0,
    'overdue' => 0,
    'due_today' => 0,
    'due_this_week' => 0
];

$recent_tasks = [];
$upcoming_tasks = [];

try {
    // Get basic statistics
    $stmt = $pdo->prepare("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'Abandoned' THEN 1 ELSE 0 END) as abandoned,
        SUM(CASE WHEN status = 'Active' AND target_date < CURDATE() THEN 1 ELSE 0 END) as overdue,
        SUM(CASE WHEN status = 'Active' AND target_date = CURDATE() THEN 1 ELSE 0 END) as due_today,
        SUM(CASE WHEN status = 'Active' AND target_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as due_this_week
        FROM study_goals WHERE student_id = ?");
    $stmt->execute([$_SESSION['student_id'] ?? 1]);
    $stats = $stmt->fetch();
    
    // Get recent tasks (last 5)
    $stmt = $pdo->prepare("SELECT * FROM study_goals WHERE student_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$_SESSION['student_id'] ?? 1]);
    $recent_tasks = $stmt->fetchAll();
    
    // Get upcoming tasks (next 7 days)
    $stmt = $pdo->prepare("SELECT * FROM study_goals WHERE student_id = ? AND status = 'Active' AND target_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY target_date ASC LIMIT 10");
    $stmt->execute([$_SESSION['student_id'] ?? 1]);
    $upcoming_tasks = $stmt->fetchAll();
    
} catch (PDOException $e) {
    // Handle database errors gracefully
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Student Study Planner</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            min-height: 100vh;
            color: white;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .header-content {
            text-align: left;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            color: #ccc;
            flex-shrink: 0;
        }

        .profile-btn {
            padding: 6px 12px;
            background: linear-gradient(135deg, #8b5cf6, #a855f7);
            color: white;
            text-decoration: none;
            border-radius: 20px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 5px;
            box-shadow: 0 2px 10px rgba(139, 92, 246, 0.3);
        }

        .profile-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.5);
        }

        .logout-btn {
            padding: 8px 16px;
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            text-decoration: none;
            border-radius: 8px;
            border: 1px solid rgba(239, 68, 68, 0.3);
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.3);
            transform: translateY(-2px);
        }

        .header h1 {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .header .purple {
            color: #8b5cf6;
        }

        .header .blue {
            color: #a855f7;
        }

        .header p {
            color: #ccc;
            font-size: 1.1rem;
        }

        .nav-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .nav-btn {
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .nav-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .nav-btn.active {
            background: linear-gradient(135deg, #8b5cf6, #a855f7);
            border-color: transparent;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(139, 92, 246, 0.3);
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .stat-label {
            color: #ccc;
            font-size: 1rem;
        }

        .stat-card.overdue .stat-icon,
        .stat-card.overdue .stat-number {
            color: #ef4444;
        }

        .stat-card.due-today .stat-icon,
        .stat-card.due-today .stat-number {
            color: #f59e0b;
        }

        .stat-card.completed .stat-icon,
        .stat-card.completed .stat-number {
            color: #22c55e;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .content-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .content-card h3 {
            color: #8b5cf6;
            margin-bottom: 20px;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .task-list {
            list-style: none;
        }

        .task-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            border-left: 4px solid #8b5cf6;
            transition: all 0.3s ease;
        }

        .task-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .task-item.overdue {
            border-left-color: #ef4444;
        }

        .task-item.due-today {
            border-left-color: #f59e0b;
        }

        .task-title {
            font-weight: bold;
            color: #8b5cf6;
            margin-bottom: 5px;
        }

        .task-description {
            color: #ccc;
            font-size: 0.9rem;
            margin-bottom: 8px;
            line-height: 1.4;
        }

        .task-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.8rem;
            color: #888;
        }

        .task-priority {
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: bold;
        }

        .priority-high {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }

        .priority-medium {
            background: rgba(245, 158, 11, 0.2);
            color: #f59e0b;
        }

        .priority-low {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
        }

        .empty-state {
            text-align: center;
            color: #888;
            padding: 40px;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .progress-section {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 30px;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .progress-title {
            color: #8b5cf6;
            font-size: 1.3rem;
        }

        .progress-percentage {
            font-size: 2rem;
            font-weight: bold;
            color: #22c55e;
        }

        .progress-bar {
            width: 100%;
            height: 12px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 15px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #8b5cf6, #a855f7);
            transition: width 0.5s ease;
        }

        .progress-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }

        .progress-stat {
            text-align: center;
        }

        .progress-stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #8b5cf6;
        }

        .progress-stat-label {
            color: #ccc;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .nav-buttons {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-content">
                <h1>
                    <span class="purple">Study</span> <span class="blue">Dashboard</span>
                </h1>
                <p>Track your academic progress and stay organized</p>
            </div>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?>!</span>
                <a href="profile.php" class="profile-btn">
                    <i class="fas fa-user"></i> Profile
                </a>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <div class="nav-buttons">
            <a href="dashboard.php" class="nav-btn active">
                <i class="fas fa-chart-line"></i> Dashboard
            </a>
            <a href="student_study_planner.php" class="nav-btn">
                <i class="fas fa-tasks"></i> Study Planner
            </a>
        </div>

        <!-- Progress Overview -->
        <div class="progress-section">
            <div class="progress-header">
                <h3 class="progress-title">Overall Progress</h3>
                <div class="progress-percentage">
                    <?php echo $stats['total'] > 0 ? round(($stats['completed'] / $stats['total']) * 100) : 0; ?>%
                </div>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo $stats['total'] > 0 ? ($stats['completed'] / $stats['total']) * 100 : 0; ?>%"></div>
            </div>
            <div class="progress-stats">
                <div class="progress-stat">
                    <div class="progress-stat-number"><?php echo $stats['total']; ?></div>
                    <div class="progress-stat-label">Total Tasks</div>
                </div>
                <div class="progress-stat">
                    <div class="progress-stat-number"><?php echo $stats['completed']; ?></div>
                    <div class="progress-stat-label">Completed</div>
                </div>
                <div class="progress-stat">
                    <div class="progress-stat-number"><?php echo $stats['active']; ?></div>
                    <div class="progress-stat-label">Active</div>
                </div>
                <div class="progress-stat">
                    <div class="progress-stat-number"><?php echo $stats['abandoned']; ?></div>
                    <div class="progress-stat-label">Abandoned</div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card overdue">
                <div class="stat-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-number"><?php echo $stats['overdue']; ?></div>
                <div class="stat-label">Overdue Tasks</div>
            </div>
            
            <div class="stat-card due-today">
                <div class="stat-icon">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="stat-number"><?php echo $stats['due_today']; ?></div>
                <div class="stat-label">Due Today</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-week"></i>
                </div>
                <div class="stat-number"><?php echo $stats['due_this_week']; ?></div>
                <div class="stat-label">Due This Week</div>
            </div>
            
            <div class="stat-card completed">
                <div class="stat-icon">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="stat-number"><?php echo $stats['completed']; ?></div>
                <div class="stat-label">Tasks Completed</div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Recent Tasks -->
            <div class="content-card">
                <h3>
                    <i class="fas fa-clock"></i>
                    Recent Tasks
                </h3>
                <?php if (!empty($recent_tasks)): ?>
                    <ul class="task-list">
                        <?php foreach ($recent_tasks as $task): ?>
                            <li class="task-item">
                                <div class="task-title"><?php echo htmlspecialchars($task['title']); ?></div>
                                <div class="task-description"><?php echo htmlspecialchars(substr($task['description'], 0, 100)) . (strlen($task['description']) > 100 ? '...' : ''); ?></div>
                                <div class="task-meta">
                                    <span><?php echo date('M j, Y', strtotime($task['created_at'])); ?></span>
                                    <span class="task-priority priority-<?php echo strtolower($task['priority']); ?>">
                                        <?php echo $task['priority']; ?>
                                    </span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-clipboard-list"></i>
                        <p>No tasks created yet.</p>
                        <p>Start by adding your first study task!</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Upcoming Tasks -->
            <div class="content-card">
                <h3>
                    <i class="fas fa-calendar-alt"></i>
                    Upcoming Tasks
                </h3>
                <?php if (!empty($upcoming_tasks)): ?>
                    <ul class="task-list">
                        <?php foreach ($upcoming_tasks as $task): ?>
                            <?php 
                            $is_overdue = strtotime($task['target_date']) < time();
                            $is_due_today = date('Y-m-d', strtotime($task['target_date'])) === date('Y-m-d');
                            $task_class = $is_overdue ? 'overdue' : ($is_due_today ? 'due-today' : '');
                            ?>
                            <li class="task-item <?php echo $task_class; ?>">
                                <div class="task-title"><?php echo htmlspecialchars($task['title']); ?></div>
                                <div class="task-description"><?php echo htmlspecialchars(substr($task['description'], 0, 100)) . (strlen($task['description']) > 100 ? '...' : ''); ?></div>
                                <div class="task-meta">
                                    <span>
                                        <i class="fas fa-calendar"></i>
                                        <?php echo date('M j, Y', strtotime($task['target_date'])); ?>
                                        <?php if ($is_overdue): ?>
                                            <span style="color: #ef4444;">(Overdue)</span>
                                        <?php elseif ($is_due_today): ?>
                                            <span style="color: #f59e0b;">(Today)</span>
                                        <?php endif; ?>
                                    </span>
                                    <span class="task-priority priority-<?php echo strtolower($task['priority']); ?>">
                                        <?php echo $task['priority']; ?>
                                    </span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-check"></i>
                        <p>No upcoming tasks.</p>
                        <p>Great job staying on top of your studies!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive effects
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Animate progress bar on load
        window.addEventListener('load', function() {
            const progressFill = document.querySelector('.progress-fill');
            const width = progressFill.style.width;
            progressFill.style.width = '0%';
            
            setTimeout(() => {
                progressFill.style.width = width;
            }, 500);
        });
    </script>
</body>
</html>
