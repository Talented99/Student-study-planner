<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit();
}

$error_message = '';
$success_message = '';

// Get current user data
$user = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM student WHERE id = ?");
    $stmt->execute([$_SESSION['student_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $error_message = "Error loading profile: " . $e->getMessage();
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $index_number = trim($_POST['index_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $bio = trim($_POST['bio'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($name) || empty($index_number) || empty($email) || empty($gender)) {
        $error_message = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        try {
            // Check if email or index number already exists (excluding current user)
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM student WHERE (email = ? OR index_number = ?) AND id != ?");
            $stmt->execute([$email, $index_number, $_SESSION['student_id']]);
            if ($stmt->fetchColumn() > 0) {
                $error_message = "Email or Index Number already exists.";
            } else {
                // Handle profile picture upload
                $profile_picture = $user['profile_picture'] ?? null;
                
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = 'uploads/profiles/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_info = pathinfo($_FILES['profile_picture']['name']);
                    $file_extension = strtolower($file_info['extension']);
                    
                    // Validate file type
                    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                    if (!in_array($file_extension, $allowed_types)) {
                        $error_message = "Only JPG, JPEG, PNG, and GIF files are allowed.";
                    } else {
                        // Generate unique filename
                        $new_filename = 'profile_' . $_SESSION['student_id'] . '_' . time() . '.' . $file_extension;
                        $upload_path = $upload_dir . $new_filename;
                        
                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                            $profile_picture = $upload_path;
                            
                            // Delete old profile picture if exists
                            if ($user['profile_picture'] && file_exists($user['profile_picture'])) {
                                unlink($user['profile_picture']);
                            }
                        } else {
                            $error_message = "Error uploading profile picture.";
                        }
                    }
                }
                
                if (empty($error_message)) {
                    // Handle password change if provided
                    $password_sql = '';
                    $password_params = [];
                    
                    if (!empty($current_password)) {
                        if (!password_verify($current_password, $user['password'])) {
                            $error_message = "Current password is incorrect.";
                        } elseif (empty($new_password)) {
                            $error_message = "New password is required.";
                        } elseif ($new_password !== $confirm_password) {
                            $error_message = "New passwords do not match.";
                        } elseif (strlen($new_password) < 6) {
                            $error_message = "New password must be at least 6 characters long.";
                        } else {
                            $password_sql = ', password = ?';
                            $password_params[] = password_hash($new_password, PASSWORD_DEFAULT);
                        }
                    }
                    
                    if (empty($error_message)) {
                        // Update profile
                        $stmt = $pdo->prepare("UPDATE student SET name = ?, index_number = ?, email = ?, gender = ?, bio = ?, phone = ?, profile_picture = ?" . $password_sql . " WHERE id = ?");
                        $params = array_merge([$name, $index_number, $email, $gender, $bio, $phone, $profile_picture], $password_params, [$_SESSION['student_id']]);
                        $stmt->execute($params);
                        
                        // Update session data
                        $_SESSION['student_name'] = $name;
                        
                        $success_message = "Profile updated successfully!";
                        
                        // Refresh user data
                        $stmt = $pdo->prepare("SELECT * FROM student WHERE id = ?");
                        $stmt->execute([$_SESSION['student_id']]);
                        $user = $stmt->fetch();
                    }
                }
            }
        } catch (PDOException $e) {
            $error_message = "Error updating profile: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Student Study Planner</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            min-height: 100vh;
            color: white;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            color: #ccc;
        }

        .logout-btn {
            padding: 8px 16px;
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            text-decoration: none;
            border-radius: 8px;
            border: 1px solid rgba(239, 68, 68, 0.3);
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.3);
            transform: translateY(-2px);
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }

        .header .purple {
            color: #8b5cf6;
        }

        .header .blue {
            color: #a855f7;
        }

        .nav-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .nav-btn {
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .nav-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .nav-btn.active {
            background: linear-gradient(135deg, #8b5cf6, #a855f7);
            border-color: transparent;
        }

        .profile-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .profile-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
            height: fit-content;
        }

        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 20px;
            border: 4px solid #8b5cf6;
            background: rgba(255, 255, 255, 0.1);
        }

        .profile-picture-placeholder {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            border: 4px solid #8b5cf6;
            font-size: 3rem;
            color: #8b5cf6;
        }

        .profile-name {
            font-size: 1.5rem;
            font-weight: bold;
            color: #8b5cf6;
            margin-bottom: 10px;
        }

        .profile-email {
            color: #ccc;
            margin-bottom: 15px;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-top: 20px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #8b5cf6;
        }

        .stat-label {
            font-size: 0.8rem;
            color: #ccc;
        }

        .edit-form {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-section {
            margin-bottom: 30px;
        }

        .form-section h3 {
            color: #8b5cf6;
            margin-bottom: 20px;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: white;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: none;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 16px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.5);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: #ccc;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
            font-family: inherit;
        }

        .file-input-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .file-input {
            position: absolute;
            left: -9999px;
        }

        .file-input-label {
            display: block;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            color: white;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .file-input-label:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .file-input-label i {
            margin-right: 8px;
        }

        .current-password-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 20px;
            border-left: 4px solid #8b5cf6;
        }

        .current-password-section h4 {
            color: #8b5cf6;
            margin-bottom: 15px;
        }

        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #a855f7);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4);
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }

        .error {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 768px) {
            .profile-container {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .nav-buttons {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                <span class="purple">Student</span> <span class="blue">Profile</span>
            </h1>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?>!</span>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Navigation -->
        <div class="nav-buttons">
            <a href="dashboard.php" class="nav-btn">
                <i class="fas fa-chart-line"></i> Dashboard
            </a>
            <a href="student_study_planner.php" class="nav-btn">
                <i class="fas fa-tasks"></i> Study Planner
            </a>
            <a href="profile.php" class="nav-btn active">
                <i class="fas fa-user"></i> Profile
            </a>
        </div>

        <?php if ($error_message): ?>
            <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <div class="profile-container">
            <!-- Profile Card -->
            <div class="profile-card">
                <?php if ($user && $user['profile_picture']): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" class="profile-picture">
                <?php else: ?>
                    <div class="profile-picture-placeholder">
                        <i class="fas fa-user"></i>
                    </div>
                <?php endif; ?>

                <div class="profile-name"><?php echo htmlspecialchars($user['name'] ?? 'Student'); ?></div>
                <div class="profile-email"><?php echo htmlspecialchars($user['email'] ?? ''); ?></div>

                <?php if ($user && $user['bio']): ?>
                    <p style="color: #ccc; margin: 15px 0; line-height: 1.5;"><?php echo htmlspecialchars($user['bio']); ?></p>
                <?php endif; ?>

                <div class="profile-stats">
                    <div class="stat-item">
                        <div class="stat-number"><?php echo $user['gender'] ?? 'N/A'; ?></div>
                        <div class="stat-label">Gender</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number"><?php echo $user['index_number'] ?? 'N/A'; ?></div>
                        <div class="stat-label">Index No.</div>
                    </div>
                </div>
            </div>

            <!-- Edit Form -->
            <div class="edit-form">
                <form method="POST" action="" enctype="multipart/form-data">
                    <!-- Profile Picture Section -->
                    <div class="form-section">
                        <h3><i class="fas fa-camera"></i> Profile Picture</h3>
                        <div class="form-group">
                            <div class="file-input-wrapper">
                                <input type="file" id="profile_picture" name="profile_picture" class="file-input" accept="image/*">
                                <label for="profile_picture" class="file-input-label">
                                    <i class="fas fa-upload"></i> Choose Profile Picture
                                </label>
                            </div>
                            <small style="color: #ccc; margin-top: 5px; display: block;">
                                Supported formats: JPG, JPEG, PNG, GIF (Max 5MB)
                            </small>
                        </div>
                    </div>

                    <!-- Personal Information Section -->
                    <div class="form-section">
                        <h3><i class="fas fa-user-edit"></i> Personal Information</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name *</label>
                                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="index_number">Index Number *</label>
                                <input type="text" id="index_number" name="index_number" value="<?php echo htmlspecialchars($user['index_number'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender *</label>
                                <select id="gender" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo ($user['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($user['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                                    <option value="Other" <?php echo ($user['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Enter your phone number">
                        </div>
                        <div class="form-group">
                            <label for="bio">Bio</label>
                            <textarea id="bio" name="bio" placeholder="Tell us about yourself..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                        </div>
                    </div>

                    <!-- Password Change Section -->
                    <div class="form-section">
                        <h3><i class="fas fa-lock"></i> Change Password</h3>
                        <div class="current-password-section">
                            <h4>Leave blank if you don't want to change your password</h4>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="current_password">Current Password</label>
                                    <input type="password" id="current_password" name="current_password" placeholder="Enter current password">
                                </div>
                                <div class="form-group">
                                    <label for="new_password">New Password</label>
                                    <input type="password" id="new_password" name="new_password" placeholder="Enter new password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // File input preview
        document.getElementById('profile_picture').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const profilePicture = document.querySelector('.profile-picture') || document.querySelector('.profile-picture-placeholder');
                    if (profilePicture) {
                        if (profilePicture.classList.contains('profile-picture-placeholder')) {
                            profilePicture.outerHTML = `<img src="${e.target.result}" alt="Profile Picture" class="profile-picture">`;
                        } else {
                            profilePicture.src = e.target.result;
                        }
                    }
                };
                reader.readAsDataURL(file);
            }
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const indexNumber = document.getElementById('index_number').value.trim();
            const email = document.getElementById('email').value.trim();
            const gender = document.getElementById('gender').value;
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;

            if (!name || !indexNumber || !email || !gender) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                return false;
            }

            // Password validation
            if (currentPassword || newPassword || confirmPassword) {
                if (!currentPassword) {
                    e.preventDefault();
                    alert('Current password is required to change password.');
                    return false;
                }
                if (!newPassword) {
                    e.preventDefault();
                    alert('New password is required.');
                    return false;
                }
                if (newPassword !== confirmPassword) {
                    e.preventDefault();
                    alert('New passwords do not match.');
                    return false;
                }
                if (newPassword.length < 6) {
                    e.preventDefault();
                    alert('New password must be at least 6 characters long.');
                    return false;
                }
            }
        });

        // Add interactive effects
        document.querySelectorAll('.form-group input, .form-group textarea, .form-group select').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>
