<?php
session_start();

// Redirect based on authentication status
if (isset($_SESSION['student_id'])) {
    // User is logged in, redirect to dashboard
    header('Location: dashboard.php');
} else {
    // User is not logged in, redirect to login
    header('Location: login.php');
}
exit();
?>
