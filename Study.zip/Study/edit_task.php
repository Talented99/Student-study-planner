<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit();
}

$task_id = (int)($_GET['id'] ?? 0);
$error_message = '';
$success_message = '';

// Get task details
$task = null;
if ($task_id > 0) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM study_goals WHERE id = ? AND student_id = ?");
        $stmt->execute([$task_id, $_SESSION['student_id'] ?? 1]);
        $task = $stmt->fetch();
        
        if (!$task) {
            $error_message = "Task not found or you don't have permission to edit it.";
        }
    } catch (PDOException $e) {
        $error_message = "Error loading task: " . $e->getMessage();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $task) {
    $subject = trim($_POST['subject'] ?? '');
    $task_desc = trim($_POST['task'] ?? '');
    $due_date = $_POST['due_date'] ?? '';
    $priority = $_POST['priority'] ?? 'Medium';
    $status = $_POST['status'] ?? 'Active';
    
    if (!empty($subject) && !empty($task_desc) && !empty($due_date)) {
        try {
            $stmt = $pdo->prepare("UPDATE study_goals SET title = ?, description = ?, target_date = ?, priority = ?, status = ? WHERE id = ? AND student_id = ?");
            $stmt->execute([$subject, $task_desc, $due_date, $priority, $status, $task_id, $_SESSION['student_id'] ?? 1]);
            
            $success_message = "Task updated successfully!";
            
            // Refresh task data
            $stmt = $pdo->prepare("SELECT * FROM study_goals WHERE id = ? AND student_id = ?");
            $stmt->execute([$task_id, $_SESSION['student_id'] ?? 1]);
            $task = $stmt->fetch();
            
        } catch (PDOException $e) {
            $error_message = "Error updating task: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task - Student Study Planner</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            min-height: 100vh;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .edit-container {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 600px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #8b5cf6;
            margin-bottom: 10px;
        }

        .header p {
            color: #ccc;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: white;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: none;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 16px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.5);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
            font-family: inherit;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            text-align: center;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #a855f7);
            color: white;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4);
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }

        .error {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .task-info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #8b5cf6;
        }

        .task-info h3 {
            color: #8b5cf6;
            margin-bottom: 10px;
        }

        .task-info p {
            color: #ccc;
            margin-bottom: 5px;
        }

        @media (max-width: 600px) {
            .edit-container {
                margin: 20px;
                padding: 30px 20px;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <div class="header">
            <h1><i class="fas fa-edit"></i> Edit Study Task</h1>
            <p>Update your study task details below</p>
        </div>

        <?php if ($error_message): ?>
            <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <?php if ($task): ?>
            <div class="task-info">
                <h3>Current Task Information</h3>
                <p><strong>Subject:</strong> <?php echo htmlspecialchars($task['title']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($task['status']); ?></p>
                <p><strong>Priority:</strong> <?php echo htmlspecialchars($task['priority']); ?></p>
                <p><strong>Created:</strong> <?php echo date('F j, Y', strtotime($task['created_at'])); ?></p>
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($task['title']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="task">Task Description</label>
                    <textarea id="task" name="task" required><?php echo htmlspecialchars($task['description']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="due_date">Due Date</label>
                    <input type="date" id="due_date" name="due_date" value="<?php echo $task['target_date']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="priority">Priority</label>
                    <select id="priority" name="priority" required>
                        <option value="Low" <?php echo $task['priority'] === 'Low' ? 'selected' : ''; ?>>Low</option>
                        <option value="Medium" <?php echo $task['priority'] === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                        <option value="High" <?php echo $task['priority'] === 'High' ? 'selected' : ''; ?>>High</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="Active" <?php echo $task['status'] === 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Completed" <?php echo $task['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Abandoned" <?php echo $task['status'] === 'Abandoned' ? 'selected' : ''; ?>>Abandoned</option>
                    </select>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Task
                    </button>
                    <a href="student_study_planner.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Planner
                    </a>
                </div>
            </form>
        <?php else: ?>
            <div class="message error">
                <p>Task not found or you don't have permission to edit it.</p>
                <a href="student_study_planner.php" class="btn btn-secondary" style="margin-top: 15px;">
                    <i class="fas fa-arrow-left"></i> Back to Planner
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('due_date').min = today;

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const subject = document.getElementById('subject').value.trim();
            const task = document.getElementById('task').value.trim();
            const dueDate = document.getElementById('due_date').value;

            if (!subject || !task || !dueDate) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
        });

        // Add interactive effects
        document.querySelectorAll('.form-group input, .form-group textarea, .form-group select').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>
